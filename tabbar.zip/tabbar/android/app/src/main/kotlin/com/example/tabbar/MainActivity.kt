package com.example.tabbar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
